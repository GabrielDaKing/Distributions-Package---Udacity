from setuptools import setup

setup(name='gabriel_udacity_distributions',
      version='0.9',
      description='Gaussian and Binomial distributions',
      packages=['gabriel_udacity_distributions'],
      author='Gabriel Francis',
      author_email='gncis8@gmail.com',
      zip_safe=False)